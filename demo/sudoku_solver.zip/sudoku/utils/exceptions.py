class InvalidSudokuError(Exception):
    """Raised when the Sudoku board is invalid.

    Args:
        Exception (type): The type of the exception.
    """
